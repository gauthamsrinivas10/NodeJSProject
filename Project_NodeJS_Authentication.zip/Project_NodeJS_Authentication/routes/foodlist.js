const {Router} = require("express");
const AuthMiddleware = require("../middleware/auth");
const app = Router();
const { FoodModel } =  require("../schema/food")

const {APP_SECRET_KEY  }= require("../config")

app.get("/", (req,res)=>{
    try
    {      
        console.log(req.user)
        res.json([])
    }
    catch(error) 
    {
        res.status(401).json(null)
    }   
} )

app.post("/", AuthMiddleware, (req,res)=>{
    try
    {      
        console.log(req.user)
        res.json([])
    }
    catch(error) 
    {
        res.status(401).json(null)
    }   
} )
module.exports = app;
