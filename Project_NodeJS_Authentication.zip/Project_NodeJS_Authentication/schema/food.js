const { Schema, model} = require("mongoose");

const FoodSchema = new Schema({
    id : {type: String, required: true},
    Name : {type:String , required:true},
    Price : {type:String , required:true},
    Description : {type:String , required : true }
})

const FoodModel = model("food",FoodSchema , "FoodItems" );
module.exports = {FoodSchema, FoodModel}