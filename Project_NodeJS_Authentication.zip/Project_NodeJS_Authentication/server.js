const express = require("express");
const jwt = require("jsonwebtoken");
const {APP_SECRET_KEY  }= require("./config");
const app = express();
const bcrypt = require("bcrypt");

require("./db")

const AuthMiddleware = require("./middleware/auth")


const UserRouter = require("./routes/user");
const FoodRouter = require("./routes/foodlist");
const { FoodModel } = require("./schema/food");
const { UserModel } = require("./schema/user");
app.use(express.json());
app.use("/user",  UserRouter)
app.use("/FoodDelivery" ,AuthMiddleware, FoodRouter)



app.post("/add-food", AuthMiddleware,  (req,res)=>{
    try{
        const {body} = req;
        const {id,Name,Price,Description } = body
        if(id && Name && Price  && id !== "" && Name !== "", Price !== ""){            
            const newItem = new FoodModel({id , Name  ,Price , Description})
            const doc =  newItem.save();
        res.json({message: "new Food added", id, Name , Price , Description})
    
        }
        else{
            res.status(401).json({message: "invalid input"})
        }
    
        
    }
    catch(error){
        res.status(500).json({message: "internal server error"})
    }
  
})





app.listen(6702)