const { connect } = require("mongoose");

async function main(){

    const mongourl = "mongodb://localhost:27017/FoodDelivery" 
    connect(mongourl)
}
main();